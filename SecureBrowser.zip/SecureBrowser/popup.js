document.addEventListener("DOMContentLoaded", () => {
    const safeBrowsing = document.getElementById("safeBrowsing");
    const phishingDetection = document.getElementById("phishingDetection");
    const maliciousUrlBlocking = document.getElementById("maliciousUrlBlocking");
  
    if (!safeBrowsing || !phishingDetection || !maliciousUrlBlocking) {
      console.error("❌ Missing toggle elements in popup.html.");
      return;
    }
  
    chrome.storage.sync.get(["safeBrowsing", "phishingDetection", "maliciousUrlBlocking"], (data) => {
      safeBrowsing.checked = data.safeBrowsing ?? false;
      phishingDetection.checked = data.phishingDetection ?? false;
      maliciousUrlBlocking.checked = data.maliciousUrlBlocking ?? false;
    });
  
    safeBrowsing.addEventListener("change", () => {
      chrome.storage.sync.set({ safeBrowsing: safeBrowsing.checked });
    });
  
    phishingDetection.addEventListener("change", () => {
      chrome.storage.sync.set({ phishingDetection: phishingDetection.checked });
    });
  
    maliciousUrlBlocking.addEventListener("change", () => {
      chrome.storage.sync.set({ maliciousUrlBlocking: maliciousUrlBlocking.checked });
    });

    function updateRules() {
        chrome.runtime.sendMessage({
          action: "updateRuleset",
          maliciousUrlBlocking: maliciousUrlBlocking.checked
        });
      }
      
      // Trigger update on toggle
      maliciousUrlBlocking.addEventListener("change", updateRules);
      
  });
  