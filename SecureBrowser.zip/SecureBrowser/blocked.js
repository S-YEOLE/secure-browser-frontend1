document.addEventListener("DOMContentLoaded", function () {
    const params = new URLSearchParams(window.location.search);
    const blockedDomain = params.get("url");

    if (blockedDomain) {
        document.getElementById("blocked-url").innerText = `https://${blockedDomain}`;

        document.getElementById("allow-site").addEventListener("click", function () {
            chrome.storage.sync.get("allowedSites", function (data) {
                let allowedSites = data.allowedSites || [];

                if (!allowedSites.includes(blockedDomain)) {
                    allowedSites.push(blockedDomain);
                    chrome.storage.sync.set({ allowedSites: allowedSites }, function () {
                        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                            chrome.tabs.update(tabs[0].id, { url: `https://${blockedDomain}` });
                        });
                    });
                }
            });
        });
    } else {
        alert("Error: Unable to retrieve blocked site.");
    }
});
