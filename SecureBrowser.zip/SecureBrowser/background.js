// Initial rule sync on install
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.sync.get(["safeBrowsing", "phishingDetection", "maliciousUrlBlocking"], (data) => {
      if (data.maliciousUrlBlocking) {
        chrome.declarativeNetRequest.updateEnabledRulesets({
          enableRulesetIds: ["malicious-urls"]
        });
      }
    });
  });
  
  // Handle popup toggle
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "updateRuleset") {
      const { maliciousUrlBlocking } = message;
      chrome.declarativeNetRequest.updateEnabledRulesets({
        enableRulesetIds: maliciousUrlBlocking ? ["malicious-urls"] : [],
        disableRulesetIds: maliciousUrlBlocking ? [] : ["malicious-urls"]
      }, () => {
        sendResponse({ success: true });
      });
  
      return true;
    }
  });
  
const GOOGLE_API_KEY = "AIzaSyCQ5xtUoR11TTMlkvOQEP6QLlTO3N1mSsE"; //API key
const API_ENDPOINT = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${GOOGLE_API_KEY}`;

// Function to check URL using Google Safe Browsing API
function checkUrlWithSafeBrowsing(url, callback) {
  const body = {
    client: {
      clientId: "securebrowser-extension",
      clientVersion: "1.0"
    },
    threatInfo: {
      threatTypes: ["MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE"],
      platformTypes: ["ANY_PLATFORM"],
      threatEntryTypes: ["URL"],
      threatEntries: [{ url }]
    }
  };

  fetch(API_ENDPOINT, {
    method: "POST",
    body: JSON.stringify(body),
    headers: { "Content-Type": "application/json" }
  })
    .then(res => res.json())
    .then(data => {
      const isUnsafe = data && data.matches && data.matches.length > 0;
      callback(isUnsafe);
    })
    .catch(error => {
      console.error("Safe Browsing API error:", error);
      callback(false);
    });
}

// Listen when a tab updates (navigates to new URL)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.url.startsWith("http")) {
    chrome.storage.sync.get("safeBrowsing", (data) => {
      if (!data.safeBrowsing) return;

      checkUrlWithSafeBrowsing(tab.url, (isUnsafe) => {
        if (isUnsafe) {
          console.log("⚠️ SecureBrowser: Blocking unsafe site -", tab.url); // ✅ Confirmation log
          chrome.tabs.update(tabId, { url: chrome.runtime.getURL("blocked.html") });
        }
      
      
      });
    });
  }
});
